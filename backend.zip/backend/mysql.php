<?php 
$mysql_host = "localhost";
$mysql_usuario = "root";
$mysql_database = "dashboard";
$mysql_senha = "";
?>